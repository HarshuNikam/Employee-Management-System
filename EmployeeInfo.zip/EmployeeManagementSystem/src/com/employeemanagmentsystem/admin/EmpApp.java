package com.employeemanagmentsystem.admin;

import java.util.Scanner;

public class EmpApp 
{
public static void main(String[] args)  
{
	
    emp e= new EmpImpl();
	

		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		while(flag)
		{
			
			System.out.println("Welcome to Employee Details : ");
			System.out.println("Enter 1 to Add details : ");
			System.out.println("Enter 2 to view Employee Details : ");
			System.out.println("Enter 3 to update Details : ");
			System.out.println("Enter 4 to Exit from Application : ");

			System.out.println("********------*******-------******");
			
			int choice =sc.nextInt();
			
			switch (choice) {
			case 1:
				e.addempInfo();
				break;

			case 2:
				 e.viewempInfo();
				break;
			case 6:
				e.updateempInfo();
				break;
			}
			
		}
}
		}
		
		


