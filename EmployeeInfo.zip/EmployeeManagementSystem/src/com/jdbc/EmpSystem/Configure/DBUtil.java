package com.jdbc.EmpSystem.Configure;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil 
{
	public Connection con=null;
		
		public static Connection getconnection() throws ClassNotFoundException, SQLException
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/reg1214","root","root");
		
			return con;
		}
		
	}





