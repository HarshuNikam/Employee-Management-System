package com.employeemanagementsystem.serviceImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


import com.employeemanagementsystem.service.emp;
import com.employeemanagmentsystem.model.EmployeeInfo;

public class EmpImpl implements emp
{
	Scanner sc=new Scanner(System.in);
	EmployeeInfo em=new EmployeeInfo();
	
@Override
public void addempInfo() throws ClassNotFoundException, SQLException 
{
	System.out.println("Enter employee ID");
	long empid=sc.nextLong();
	
	System.out.println("Enter employee Name");
	String empname=sc.next();
	
	System.out.println("Enter employee Address");
	String address=sc.next();
	
	System.out.println("Enter employee Mobile No");
	long MobileNo=sc.nextLong();
	
	
	System.out.println("Enter employee Adhar No");
	long AadharNo=sc.nextLong();
	
	System.out.println("Enter employee Gender");
	String Gender=sc.next();
	
	Connection con = com.jdbc.EmpSystem.Configure.DBUtil.getconnection();
	
	String sql="insert into employeeInfo values("+empid+",'"+empname+"','"+address+"',"+MobileNo+","
			+ ""+AadharNo+",'"+Gender+")";
	
}

@Override
public void viewempInfo() throws ClassNotFoundException, SQLException 
{
	System.out.println("Enter Your Employee Id to see details : ");
	long empid = sc.nextLong();
	
	Connection con = com.jdbc.EmpSystem.Configure.DBUtil.getconnection();
	String sql="select * from employeeInfo where empid="+empid+"";
	Statement smt = con.createStatement();
	ResultSet rs = smt.executeQuery(sql);
	
	if(rs.next())
	{
		System.out.println("Welcome to Employee section ");
		System.out.println("********************");
		System.out.println();
		System.out.println("Employee Id : "+rs.getLong(1));
		System.out.println("Employee Name "+rs.getString(2));
		System.out.println("Address : "+rs.getString("Address"));
		System.out.println("MobileNo : "+rs.getLong(4));
		System.out.println("AadharNO : "+rs.getLong(5));
		System.out.println("Gender : "+rs.getString(6));
		System.out.println();
		System.out.println("******THANK YOU**********");
		System.out.println();
		
	}
	else {
		System.out.println("Invalid Employee Id : ");
		System.out.println();
	}
	
	con.close();
	smt.close();
	
	
}

@Override
public void updateempInfo() throws ClassNotFoundException, SQLException {
	System.out.println("Enter Your Employee Id to see details : ");
	long empid = sc.nextLong();
	Connection con = com.jdbc.EmpSystem.Configure.DBUtil.getconnection();
	Statement smt = con.createStatement();
	String sql="select mobileno from employeeInfo where empid="+empid;
	ResultSet rs = smt.executeQuery(sql);
	if(rs.next())
	{
		System.out.println("Enter Your new mobile no to update");
		long newmobile=sc.nextLong();
		
	String sql2="update details set Mobileno="+newmobile+" where empid ="+empid+"";
		 smt.execute(sql2);
		 System.out.println("Mobile number Updated Successfully...!");
			
		con.close();
		smt.close();
			
				
	}
	else {
		System.out.println("Invalid Employee Id : ");
	
}
}
}
