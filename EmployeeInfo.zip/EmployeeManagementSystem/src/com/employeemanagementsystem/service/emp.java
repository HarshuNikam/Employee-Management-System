package com.employeemanagementsystem.service;

import java.sql.SQLException;

public interface emp 
{
	void addempInfo() throws ClassNotFoundException, SQLException;
	void viewempInfo() throws ClassNotFoundException, SQLException;
	void updateempInfo() throws ClassNotFoundException, SQLException;

}
